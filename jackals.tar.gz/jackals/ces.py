import random
from time import sleep

for idx in range(3):
    print idx, "hello"
    sleep(random.randint(1,3))
